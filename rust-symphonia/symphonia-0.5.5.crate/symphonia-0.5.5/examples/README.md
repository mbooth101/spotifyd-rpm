# Symphonia Examples

| Example                | Description                                                    |
|------------------------|----------------------------------------------------------------|
| `basic-interleaved.rs` | Decode a file and interleave the decoded samples for playback. |
| `getting-started.rs`   | The example from GETTING_STARTED.md.                           |
