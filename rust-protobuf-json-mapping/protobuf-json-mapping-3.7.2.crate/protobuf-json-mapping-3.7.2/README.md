<!-- cargo-sync-readme start -->

JSON printer and parser which tries to follow
[protobuf conventions](https://developers.google.com/protocol-buffers/docs/proto3#json).

<!-- cargo-sync-readme end -->
