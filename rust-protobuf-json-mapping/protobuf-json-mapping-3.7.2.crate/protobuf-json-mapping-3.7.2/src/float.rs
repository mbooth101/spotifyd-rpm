pub const PROTOBUF_JSON_NAN: &str = "NaN";
pub const PROTOBUF_JSON_INF: &str = "Infinity";
pub const PROTOBUF_JSON_MINUS_INF: &str = "-Infinity";
