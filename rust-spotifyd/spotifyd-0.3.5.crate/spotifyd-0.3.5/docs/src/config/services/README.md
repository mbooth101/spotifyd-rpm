# Running as a Service

You can run Spotifyd as a service that automatically starts in the background.
