# Command Line Options

`Spotifyd` can be configured using CLI arguments. For a detailed description as well as possible values for each flag, run

```bash
spotifyd --help
```