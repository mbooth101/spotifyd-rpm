# MacOS installation Guide

spotifyd is available via Homebrew and can be installed as follows:

`brew install spotifyd`

One can then enable it as a service at startup:

`brew services start spotifyd`