# Introduction

This is the documentation of [spotifyd][spotifyd]
> An open source Spotify client running as a UNIX daemon.

These docs should be regarded as an extension of the [README][spotifyd] so please check there first before looking through the docs.

[spotifyd]: https://github.com/Spotifyd/spotifyd