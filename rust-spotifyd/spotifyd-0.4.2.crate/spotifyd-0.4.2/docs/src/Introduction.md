# Introduction

This is the documentation of [spotifyd][spotifyd], which covers the installation and setup process as well as some advanced topics.

## Getting Help

If you're stuck in the setup process or have a question, please join the [community matrix server][matrix]. We're always willing to help!

[spotifyd]: https://github.com/Spotifyd/spotifyd
[matrix]: https://matrix.to/#/#spotifyd:matrix.org
