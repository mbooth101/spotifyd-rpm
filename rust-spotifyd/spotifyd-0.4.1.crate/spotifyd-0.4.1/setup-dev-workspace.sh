#!/bin/sh
# Author: Sven Lechner (SirWindfield)
# License: GPLv3

# Copies all hooks into the .git/hooks directory
cp hooks/* .git/hooks
