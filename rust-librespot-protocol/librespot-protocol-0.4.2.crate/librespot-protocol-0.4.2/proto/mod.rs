// generated protobuf files will be included here. See build.rs for details
#![allow(renamed_and_removed_lints)]

include!(env!("PROTO_MOD_RS"));
