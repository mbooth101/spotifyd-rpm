// generated protobuf files will be included here. See build.rs for details
include!(env!("PROTO_MOD_RS"));
